declare const initIcon: (str: string) => void;
export default initIcon;
