<?php
include '../connect/conectdb.php';
include "header.php";
include '../admin/phanquyenNhanVien.php';

$id = $_GET["MaLoaiSanPham"];
$sql = "select * from loaisanpham where MaLoaiSanPham = '$id'";
$query = mysqli_query($conn, $sql);
while ( $data = mysqli_fetch_array($query) ) {
    $Id_MaLoaiSanPham = $data["MaLoaiSanPham"];
    $tenloaisanpham = $data["TenLoaiSanPham"];
    $tinhtrang = $data["TinhTrang"];

}

if (isset($_POST["save"])) {
    $MaLoaiSanPham = $_POST["Id_MaLoaiSanPham"];
    $tenloasanpham = $_POST["tenloaisanpham"];
    $trangthai = $_POST["tinhtrang"];


            $sql = "update loaisanpham set  TenLoaiSanPham = '$tenloasanpham', TinhTrang = '$trangthai' where MaLoaiSanPham = '$id'";
            // echo $sql;
            if (mysqli_query($conn, $sql)) {
                // $kq = $conn->query($Insert);
                // $conn->close();
                echo '<script>alert ("Sửa Sản phẩm thành công rùi đó!!HiHi")</script>';
                      $conn->close();
            } else {
                echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
            }
         //   header('Location: LoaiSp.php');
        }


?>

<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Sửa thông tin loại sản phẩm
                        <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                             </span>
                    </header>
                    <div class="panel-body">
                        <div class="form">
                            <form class="cmxform form-horizontal " id="signupForm" method="post" action="">
                                <div class="form-group ">
                                    <label for="firstname" class="control-label col-lg-3">Mã Loại Sản Phẩm</label>
                                    <div class="col-lg-6">
                                        <input disabled class=" form-control" id="firstname" name="Id_MaLoaiSanPham" value="<?php echo $Id_MaLoaiSanPham ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Tên Loại Sản Phẩm</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="tenloaisanpham" value="<?php echo $tenloaisanpham ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="newsletter" class="control-label col-lg-3 col-sm-3">Tình Trạng</label>
                                    <div class="col-lg-6 col-sm-9">
                                        <!--                                            <input type="" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter">-->
                                        <select name="tinhtrang" class="form-control m-bot15">
                                            <option <?php if($tinhtrang == ''){echo("selected");}?>>--</option>
                                            <option <?php if($tinhtrang == 'hoạt động'){echo("selected");}?>>hoạt động</option>
                                            <option <?php if($tinhtrang == 'không hoạt động'){echo("selected");}?>>không hoạt động</option>

                                        </select>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-6">
                                        <input class="btn btn-primary" name="save" type="submit" value="Save">
                                        <a href="LoaiSp.php"><button class="btn btn-default"  type="button" value="Cancel">Cancel</button></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</section>
