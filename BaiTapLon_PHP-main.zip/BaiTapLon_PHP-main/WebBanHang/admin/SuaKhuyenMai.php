<?php
include '../connect/conectdb.php';
include "header.php";
include '../admin/phanquyenNhanVien.php';

$id = $_GET["Id_KhuyenMai"];
$sql = "select * from khuyenmai where Id_KhuyenMai = '$id'";
$query = mysqli_query($conn, $sql);
while ( $data = mysqli_fetch_array($query) ) {
    $Id_KhuyenMai = $data["Id_KhuyenMai"];
    $tenkhuyenmai = $data["TenKhuyenMai"];
    $loaikhuyenmai = $data["LoaiKhuyenMai"];
    $mucgiam = $data["MucGiam"];
    $thoigianbd = $data["ThoiGianBD"];
    $thoigiankt = $data["ThoiGianKT"];
    $soluong = $data["SoLuongSpApDung"];
}

if (isset($_POST["save"])) {
    $tenkm = $_POST["tenkhuyenmai"];
    $Loaikm = $_POST["loaikhuyenmai"];
    $mucgiam = $_POST["mucgiam"];
    $timebd = $_POST["thoigianbd"];
    $timekt = $_POST["thoigiankt"];
    $soluongkm = $_POST["soluong"];

    $sql = "update khuyenmai set  TenKhuyenMai = '$tenkm', LoaiKhuyenMai = '$Loaikm', MucGiam = '$mucgiam', ThoiGianBD = '$timebd', ThoiGianKT = '$timekt', SoLuongSpApDung = '$soluongkm' where Id_KhuyenMai = '$id'";
    // echo $sql;
    if (mysqli_query($conn, $sql)) {
        // $kq = $conn->query($Insert);
        // $conn->close();
        echo '<script>alert ("Sửa Khuyến Mãi thành công rùi đó!!HiHi")</script>';
        $conn->close();
    } else {
        echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
    }
    //   header('Location: LoaiSp.php');
}



?>

<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Sửa thông tin khuyến mãi
                        <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                             </span>
                    </header>
                    <div class="panel-body">
                        <div class="form">
                            <form class="cmxform form-horizontal " id="signupForm" method="post" action="" enctype="multipart/form-data">
                                <div class="form-group ">
                                    <label for="firstname" class="control-label col-lg-3">Mã Khuyến Mãi</label>
                                    <div class="col-lg-6">
                                        <input disabled class=" form-control" id="firstname" name="Id_khuyenmai" value="<?php echo $Id_KhuyenMai ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Tên Khuyến Mãi</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="tenkhuyenmai" value="<?php echo $tenkhuyenmai ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Loại Khuyến Mãi</label>
                                    <div class="col-lg-6 col-sm-9">
                                        <!--                                            <input type="" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter">-->
                                        <select name="loaikhuyenmai" class="form-control m-bot15">
                                            <option <?php if($loaikhuyenmai == ''){echo("selected");}?>>--</option>
                                            <option <?php if($loaikhuyenmai == 'Giảm theo số tiền'){echo("selected");}?>>Giảm theo số tiền</option>
                                            <option <?php if($loaikhuyenmai == 'Giảm theo phần trăm'){echo("selected");}?>>Giảm theo phần trăm</option>

                                        </select>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Mức Giảm</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="mucgiam" value="<?php echo $mucgiam ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Thời Gian Bắt Đầu</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="thoigianbd" value="<?php echo $thoigianbd ?>" type="date">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Thời Gian Kết Thúc</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="thoigiankt" value="<?php echo $thoigiankt ?>" type="date">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Số lượng Áp Dụng</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="soluong" value="<?php echo $soluong ?>" type="text">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-6">
                                        <input class="btn btn-primary" name="save" type="submit" value="Save">
                                        <a href="KhuyenMai.php"><button class="btn btn-default"  type="button" value="Cancel">Cancel</button></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</section>
