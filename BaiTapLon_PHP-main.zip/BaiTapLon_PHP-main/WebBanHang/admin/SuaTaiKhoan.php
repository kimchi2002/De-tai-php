

    <?php

       // include 'phanquyenAdmin.php';
        include "header.php";
        include "../connect/conectdb.php";
        include '../admin/phanquyenNhanVien.php';

    if (isset($_POST["save"])) {
        $id = $_POST["id"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $nameHT= $_POST["nameHT"];
        $address= $_POST["address"];
        $phone= $_POST["phone"];
        $email= $_POST["email"];

        $TinhTrang = $_POST["trangthai"];
        $loaitk = $_POST["loaitk"];
        $sql = "update `taikhoan` set TenDangNhap = '$username', Matkhau = '$password', TenHienThi = '$nameHT', DiaChi = '$address', DienThoai = '$phone' , Email = '$email' , TinhTrang = '$TinhTrang', MaLoaiTaiKhoan = '$loaitk'	where MaTaiKhoan = '$id'";
        // echo $sql;
        mysqli_query($conn, $sql);
        echo '<script>alert ("You have successfully updated")</script>';
        // header('Location: Quan-Ly-nhan-vien.php');
    }


    $id = $_GET["id"];
    $sql = "select * from taikhoan where MaTaiKhoan = '$id'";
    $query = mysqli_query($conn, $sql);
    while ( $data = mysqli_fetch_array($query) ) {
        $id = $data["MaTaiKhoan"];
        $tendangnhap = $data["TenDangNhap"];
        $matkhau = $data["MatKhau"];
        $tenHT = $data["TenHienThi"];
        $diachi = $data["DiaChi"];
        $Dienthoai = $data["DienThoai"];
        $email = $data["Email"];
        $tinhtrang = $data["TinhTrang"];
        $loaitk = $data["MaLoaiTaiKhoan"];
    }



    ?>


<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Sửa thông tin thành viên
                        <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                             </span>
                    </header>
                    <div class="panel-body">
                        <div class="form">
                            <form class="cmxform form-horizontal " id="signupForm" method="post" action="">
                                <div class="form-group ">
                                    <label for="firstname" class="control-label col-lg-3">Mã Tài Khoản</label>
                                    <div class="col-lg-6">
                                        <input class=" form-control" id="firstname" name="id" value="<?php echo $id ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="firstname" class="control-label col-lg-3">Tên Đăng Nhập</label>
                                    <div class="col-lg-6">
                                        <input class=" form-control" id="firstname" name="username" value="<?php echo $tendangnhap ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="lastname" class="control-label col-lg-3">Mật Khẩu</label>
                                    <div class="col-lg-6">
                                        <input class=" form-control" id="lastname" name="password" value="<?php echo $matkhau ?>"  type="password">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Tên Hiển Thị</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="nameHT" value="<?php echo $tenHT ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="password" class="control-label col-lg-3">Địa Chỉ</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="password" name="address" value="<?php echo $diachi ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Số điện thoại</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" pattern="^0\d{9}$" value="<?php echo $Dienthoai ?>" name="phone" type="tel">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="confirm_password" class="control-label col-lg-3">Email</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="confirm_password" value="<?php echo $email ?>" name="email" type="email">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="newsletter" class="control-label col-lg-3 col-sm-3">Trạng thái</label>
                                    <div class="col-lg-6 col-sm-9">
                                        <!--                                            <input type="" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter">-->
                                        <select name="trangthai" class="form-control m-bot15">
                                            <option value="<?php if($tinhtrang == 'hoạt động'){echo("selected");}?>">hoạt động</option>
                                            <option value="<?php if($tinhtrang == 'không hoạt động'){echo("selected");}?>">không hoạt động</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="newsletter" class="control-label col-lg-3 col-sm-3">Mã Loại tài khoản</label>
                                    <div class="col-lg-6 col-sm-9">
                                        <!--                                            <input type="" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter">-->
                                        <select name="loaitk" class="form-control m-bot15">
                                            <?php
                                            echo '<option value=" '. $loaitk.' selected">'."--". $tinhtrang . "--"."</option>";
                                            if($loaitk==1){
                                                $query = "SELECT * FROM loaitaikhoan where  $loaitk <> 1";
                                                echo $TenNhom;
                                            } else {
                                                $query = "SELECT * FROM taikhoan where  <>1";
                                                $sql = mysqli_query($conn,$query);
                                                while ($row = mysqli_fetch_array($sql)){
                                                    echo '<option value=" '. $row['IdNhom']	.'">'. $row['TenNhom'] . "</option>";}}
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-6">
                                        <input class="btn btn-primary" name="save" type="submit" value="Save">
<!--                                        <a><button class="btn btn-default" href="index.php" type="button" value="Cancel">Cancel</button></a>-->
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</section>
</section>
