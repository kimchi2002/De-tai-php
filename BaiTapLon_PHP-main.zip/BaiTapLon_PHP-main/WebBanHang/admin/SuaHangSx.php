<?php
include '../connect/conectdb.php';
include "header.php";
include '../admin/phanquyenNhanVien.php';

$id = $_GET["MaHangSanXuat"];
$sql = "select * from hangsanxuat where MaHangSanXuat = '$id'";
$query = mysqli_query($conn, $sql);
while ( $data = mysqli_fetch_array($query) ) {
    $Id_MaHangSanXuat = $data["MaHangSanXuat"];
    $tenhangsanxuat = $data["TenHangSanXuat"];
    $logo = $data["Logo"];
    $tinhtrang = $data["TinhTrang"];

}

if (isset($_POST["save"]) && isset($_FILES['logo'])) {
    $MaHangSanXuat = $_POST["Id_MaHangSanXuat"];
    $tenhangsanxuat = $_POST["tenhangsanxuat"];
    $logo = $_FILES["logo"];
    $trangthai = $_POST["tinhtrang"];

    $file_name = $_FILES['logo']['name'];
    $file_size = $_FILES['logo']['size'];
    $file_tmp = $_FILES['logo']['tmp_name'];
    $error = $_FILES['logo']['error'];


    if ($error === 0) {
        if ($file_size > (5 * 1024 * 1024)) {
            echo '<script>alert("xin lỗi, File bạn chọn to thế!!")</script>';
        } else {
            $img_ex = pathinfo($file_name, PATHINFO_EXTENSION);
            $img_ex_lc = strtolower($img_ex);

            $allowed_exs = array("jpg", "jpeg", "png");

            if (in_array($img_ex_lc, $allowed_exs)) {
                $logo = uniqid("HSX-", true) . '.' . $img_ex_lc;
                $img_upload_path = '../images/hangsanxuat/' . $logo;
                move_uploaded_file($file_tmp, $img_upload_path);

                $Update = "update hangsanxuat set  TenHangSanXuat = '$tenhangsanxuat', Logo = '$logo' , TinhTrang = '$trangthai' where MaHangSanXuat = '$id'";
                if (mysqli_query($conn, $Update)) {
                    echo '<script>alert ("Sửa Hãng Sản Xuất thành công rùi đó!!HiHi")</script>';

                } else {
                    echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
                }
            } else {

                echo '<script>alert("Bạn không chọn đúng định dạng file rồi!!")</script>';

            }
        }
    }

//    $sql = "update hangsanxuat set  TenHangSanXuat = '$tenhangsanxuat', Logo = '$logo' , TinhTrang = '$trangthai' where MaHangSanXuat = '$id'";
//    // echo $sql;
//    if (mysqli_query($conn, $sql)) {
//
//        echo '<script>alert ("Sửa hãng sản xuất thành công rùi đó!!HiHi")</script>';
//        $conn->close();
//    } else {
//        echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
//    }
    //   header('Location: LoaiSp.php');
}


?>

<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Sửa thông tin hãng sản xuất
                        <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                             </span>
                    </header>
                    <div class="panel-body">
                        <div class="form">
                            <form class="cmxform form-horizontal " id="signupForm" method="post" action="" enctype="multipart/form-data">
                                <div class="form-group ">
                                    <label for="firstname" class="control-label col-lg-3">Mã Hãng Sản Xuất</label>
                                    <div class="col-lg-6">
                                        <input disabled class=" form-control" id="firstname" name="Id_MaHangSanXuat" value="<?php echo $Id_MaHangSanXuat ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Tên Hãng Sản Xuất</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="tenhangsanxuat" value="<?php echo $tenhangsanxuat ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Logo Cũ</label>
                                    <div class="col-lg-6">
                                        <?php
                                            $sql = "SELECT * FROM hangsanxuat where MaHangSanXuat = '$id'";
                                            $res = mysqli_query($conn,  $sql);
                                            if (mysqli_num_rows($res) > 0) {
                                            while ($row = mysqli_fetch_assoc($res)) {
                                        ?>
<!--                                        <input class="form-control " id="username" name="logo" value="--><?php //echo $logo ?><!--" type="text">-->
                                                <img src="../images/hangsanxuat/<?php echo $row['Logo'] ?>" width="100" height="100">
                                        <?php } }?>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Logo Mới</label>
                                    <div class="col-lg-6">
                                        <input id="username" name="logo" type="file">
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="newsletter" class="control-label col-lg-3 col-sm-3">Tình Trạng</label>
                                    <div class="col-lg-6 col-sm-9">
                                        <!--                                            <input type="" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter">-->
                                        <select name="tinhtrang" class="form-control m-bot15">
                                            <option <?php if($tinhtrang == ''){echo("selected");}?>>--</option>
                                            <option <?php if($tinhtrang == 'hoạt động'){echo("selected");}?>>hoạt động</option>
                                            <option <?php if($tinhtrang == 'không hoạt động'){echo("selected");}?>>không hoạt động</option>

                                        </select>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-6">
                                        <input class="btn btn-primary" name="save" type="submit" value="Save">
                                        <a href="HangSanXuat.php"><button class="btn btn-default"  type="button" value="Cancel">Cancel</button></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</section>
