
    <?php

        include "phanquyenNhanVien.php";
        include "header.php";
        include "../connect/conectdb.php";
$username= "";
$password = "";
$nameHT="";
$address="";
$phone="";
$email="";
$trangthai="";
$loaitk="";

        if(isset($_POST['save'])) {

            if (isset($_POST['username'])) {
                $username = $_POST['username'];
            }
            if (isset($_POST['password'])) {
                $password = md5($_POST['password']);
            }
            if (isset($_POST['nameHT'])) {
                $nameHT = $_POST['nameHT'];
            }
            if (isset($_POST['address'])) {
                $address = $_POST['address'];
            }
            if (isset($_POST['phone'])) {
                $phone = $_POST['phone'];
            }
            if (isset($_POST['email'])) {
                $email = $_POST['email'];
            }
            if (isset($_POST['trangthai'])) {
                $trangthai = $_POST['trangthai'];
            }
            if (isset($_POST['loaitk'])) {
                $loaitk = $_POST['loaitk'];
            }

            if (isset($username) && isset($password) && isset($nameHT) && isset($address) && isset($phone) && isset($email) && isset($trangthai) && isset($loaitk)) {
                $sql = "select * from taikhoan where TenDangNhap = '$username'";
                $check = $conn->query($sql);
                $sql1 = "select * from taikhoan where Email = '$email'";
                $check1 = $conn->query($sql1);
                $sql2 = "select * from taikhoan where DienThoai = '$phone'";
                $check2 = $conn->query($sql2);
                $sql3 = "select * from taikhoan where TenHienThi = '$nameHT'";
                $check3 = $conn->query($sql3);

//                do {
                    if (mysqli_num_rows($check) > 0) {
                        echo '<script>alert ("Tên đăng nhập này có người dùng r đấy")</script>';
                       // break;
                    } else if (mysqli_num_rows($check1) > 0 || (!filter_var($email, FILTER_VALIDATE_EMAIL))) {
                        echo '<script>alert ("Email có người dùng rồi hoặc nhập sai r!! dùng cái khác~~")</script>';
                     //   break;
                    } else if (mysqli_num_rows($check2) > 0) {
                        echo '<script>alert ("Số điện thoại tồn tại rồi!!!")</script>';
                    //    break;
                    } else if (mysqli_num_rows($check3) > 0) {
                        echo '<script>alert ("Tên Hiển thị tồn tại rồi!!")</script>';
                     //   break;
                    } else {
                        $Insert = "insert into taikhoan(TenDangNhap,MatKhau,TenHienThi,DiaChi,DienThoai,Email,TinhTrang,MaLoaiTaiKhoan) values('$username','$password','$nameHT','$address','$phone','$email','$trangthai','$loaitk')";
                        if (mysqli_query($conn, $Insert)) {
                           // $kq = $conn->query($Insert);
                           // $conn->close();
                            echo '<script>alert ("Tạo Tài khoản thành công rùi đó!!HiHi")</script>';
                            $conn->close();
                        }else{
                            echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
                        }
//                        mysqli_query($conn, $Insert);
//                        echo '<script>alert ("Tạo Tài khoản thành công rùi đó!!HiHi")</script>';


                    }
//                }while(false);

            }
        }

    ?>

    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Đăng kí thành viên mới
                            <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                             </span>
                        </header>
                        <div class="panel-body">
                            <div class="form">
                                <form class="cmxform form-horizontal " id="signupForm" method="post" action="">
                                    <div class="form-group ">
                                        <label for="firstname" class="control-label col-lg-3">Tên Đăng Nhập</label>
                                        <div class="col-lg-6">
                                            <input class=" form-control" id="firstname" name="username" value="<?php echo $username ?>" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="lastname" class="control-label col-lg-3">Mật Khẩu</label>
                                        <div class="col-lg-6">
                                            <input class=" form-control" id="lastname" name="password" type="password">
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="username" class="control-label col-lg-3">Tên Hiển Thị</label>
                                        <div class="col-lg-6">
                                            <input class="form-control " id="username" name="nameHT" value="<?php echo $nameHT ?>" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="password" class="control-label col-lg-3">Địa Chỉ</label>
                                        <div class="col-lg-6">
                                            <input class="form-control " id="password" name="address" value="<?php echo $address ?>" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="username" class="control-label col-lg-3">Số điện thoại</label>
                                        <div class="col-lg-6">
                                            <input class="form-control " id="username" pattern="^0\d{9}$" value="<?php echo $phone ?>" name="phone" type="tel">
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="confirm_password" class="control-label col-lg-3">Email</label>
                                        <div class="col-lg-6">
                                            <input class="form-control " id="confirm_password" value="<?php echo $email ?>" name="email" type="email">
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="newsletter" class="control-label col-lg-3 col-sm-3">Trạng thái</label>
                                        <div class="col-lg-6 col-sm-9">
                                            <!--                                            <input type="" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter">-->
                                            <select name="trangthai" class="form-control m-bot15">
                                                <option>hoạt động</option>
                                                <option>không hoạt động</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <label for="newsletter" class="control-label col-lg-3 col-sm-3">Mã Loại tài khoản</label>
                                        <div class="col-lg-6 col-sm-9">
<!--                                            <input type="" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter">-->
                                            <select name="loaitk" class="form-control m-bot15">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-lg-offset-3 col-lg-6">
                                            <input class="btn btn-primary" name="save" type="submit" value="Save">
                                            <a><button class="btn btn-default" href="index.php" type="button" value="Cancel">Cancel</button></a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </section>
    </section>
</section>

