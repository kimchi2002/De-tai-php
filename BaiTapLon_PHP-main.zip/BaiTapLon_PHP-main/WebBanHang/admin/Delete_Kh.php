<?php

include '../connect/conectdb.php';

if(isset($_GET['MaTaiKhoan'])) {

    $MaTaiKhoan = $_GET['MaTaiKhoan'];

    $sql = "DELETE from taikhoan where  MaTaiKhoan = '$MaTaiKhoan'";

    $conn->query($sql);


    header("location: /BaiTapLon_PHP/WebBanHang/admin/updatetaiKhoan.php");
    exit();
}

if(isset($_GET['MaLoaiSanPham'])) {

    $MaLoaiSanPham = $_GET['MaLoaiSanPham'];


    $sql = "DELETE from loaisanpham where  MaLoaiSanPham = '$MaLoaiSanPham'";

    $conn->query($sql);

    header("location: /BaiTapLon_PHP/WebBanHang/admin/LoaiSp.php");
    //exit();
}

if(isset($_GET['MaHangSanXuat'])) {

    $MaHangSanXuat = $_GET['MaHangSanXuat'];


    $sql = "DELETE from hangsanxuat where  MaHangSanXuat = '$MaHangSanXuat'";

    $conn->query($sql);

    header("location: /BaiTapLon_PHP/WebBanHang/admin/HangSanXuat.php");
    //exit();
}
?>

<?php
if(isset($_GET['Id_KhuyenMai'])) {

    $km = $_GET['Id_KhuyenMai'];

    $sql = "DELETE from khuyenmai where  Id_KhuyenMai = '$km'";

    $conn->query($sql);

    header("location: /BaiTapLon_PHP/WebBanHang/admin/KhuyenMai.php");
    //exit();
}


if(isset($_GET['MaSanPham'])) {

    $sp = $_GET['MaSanPham'];

    $sql = "DELETE from sanpham where  MaSanPham = '$sp'";

    $conn->query($sql);

    header("location: /BaiTapLon_PHP/WebBanHang/admin/QLSanPham.php");
    //exit();
}


?>

<!--<script>-->
<!--    function ConfirmDelete()-->
<!--    {-->
<!--        // var x = confirm("Do you really want to delete?");-->
<!--        var x = confirm("Are you sure?")-->
<!--        if (x) {-->
<!--
//            include '../connect/conectdb.php';
//            if(isset($_GET['MaLoaiSanPham'])) {
//
//                $MaLoaiSanPham = $_GET['MaLoaiSanPham'];
//
//
//                $sql = "DELETE from loaisanpham where  MaLoaiSanPham = '$MaLoaiSanPham'";
//
//                $conn->query($sql);
//
//                header("location: /BaiTapLon_PHP/WebBanHang/admin/LoaiSp.php");
//                //exit();
//            }
//
//            x = 'xóa đc r đấy';
//        }else{
//            x = "okee nếu k muốn thì thôi!!"
//        }
//        return x;
//        // alert("này có muốn xóa thật không đấy!!!")
//    }
//</script>
