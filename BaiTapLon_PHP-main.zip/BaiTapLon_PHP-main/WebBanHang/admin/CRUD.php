<?php
//function conn(){
//    $servername = "127.0.0.1:3325";
//    $username = "root";
//    $password = "";
//    $db = "webbanhang_php";
//
//    $conn= new mysqli($servername, $username, $password, $db);
//
//    if(!$conn->connect_error){
//        return $conn;
//    }else{
//        return false;
//    }
//}
//
//function update_loaiSp(){
//    if (isset($_POST["save"])) {
////                $stt = $_POST["Stt"];
//        $MaLoaiSanPham = $_POST["MaLoaiSp"];
//        $TenLoaiSanPham = $_POST["TenLoaiSp"];
//        $TinhTrang = $_POST["tinhtrang"];
//
//        //    where MaLoaiSanPham = '$MaLoaiSanPham'
//        $sql = "update loaisanpham set TenLoaiSanPham = '$TenLoaiSanPham', TinhTrang = '$TinhTrang' where MaLoaiSanPham = '$MaLoaiSanPham'";
//        // echo $sql;
//        $a =mysqli_query($conn, $sql);
//        if ($a) {
//            echo '<script>alert ("You have successfully updated")</script>';
//        } else {
//            echo '<script>alert ("You have false updated")</script>';
//        }
//
//        //      $conn->close();
//    }
//}
//
//?>

// Kiểm tra xem biểu mẫu đã được gửi chưa
//                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
//                            // Kiểm tra xem tệp đã được tải lên mà không có lỗi hay không
//                            if (isset($_FILES["Logo"]) && $_FILES["Logo"]["error"] == 0) {
//                                $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
//                                $filename = $_FILES["Logo"]["name"];
//                                $filetype = $_FILES["Logo"]["type"];
//                                $filesize = $_FILES["Logo"]["size"];
//
//                                // Xác minh phần mở rộng tệp
//                                $ext = pathinfo($filename, PATHINFO_EXTENSION);
//                                if (!array_key_exists($ext, $allowed)) die("Lỗi: Vui lòng chọn định dạng tệp hợp lệ.");
//
//                                // Xác minh kích thước tệp - tối đa 5MB
//                                $maxsize = 5 * 1024 * 1024;
//                                if ($filesize > $maxsize) die("Lỗi: Kích thước tệp lớn hơn giới hạn cho phép.");
//
//                                // Xác minh loại MIME của tệp
//                                if (in_array($filetype, $allowed)) {
//                                    // Kiểm tra xem tệp có tồn tại hay không trước khi tải lên
//                                    if (file_exists("../images/hangsanxuat/" . $filename)) {
//                                        echo $filename . " đã tồn tại.";
//                                    }
//                                }
//                            }
//                        }


//if (isset($_POST['Logo'])) {
//$errors= array();
//                        $file_name = $_FILES['Logo']['name'];
//                        $file_size = $_FILES['Logo']['size'];
//                        $file_tmp = $_FILES['Logo']['tmp_name'];
//                        $file_type = $_FILES['Logo']['type'];
//                        $file_parts =explode('.',$_FILES['Logo']['name']);
//                        $file_ext=strtolower(end($file_parts));
//                        $expensions= array("jpeg","jpg","png");
//                        if(in_array($file_ext,$expensions)=== false){
//                            echo '<script> alert("Chỉ hỗ trợ upload file JPEG hoặc PNG.")</script>';
//                        }
//                        if($file_size > (5*1024*1024)) {
//                            $errors[]='Kích thước file không được lớn hơn 2MB';
//                        }
//                        $image = $_FILES['Logo']['name'];
//                        $target = "../images/hangsanxuat/".basename($image);
//                        $sql = "INSERT INTO images (image) VALUES ('$image')";
//                        mysqli_query($conn, $sql);
//                        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
//                        echo '<script language="javascript">alert("Đã upload thành công!");</script>';
//                        }else{
//                        echo '<script language="javascript">alert("Đã upload thất bại!");</script>';
//                        }
//                        }
//                        $result = mysqli_query($conn, "SELECT * FROM images");
