<?php
include '../connect/conectdb.php';
include "header.php";
include '../admin/phanquyenNhanVien.php';

$queryLoaisp = "select * from loaisanpham";
$queryLoaisp1 = mysqli_query($conn,$queryLoaisp);

$queryHangSx = "select * from hangsanxuat";
$queryhangsx1 = mysqli_query($conn,$queryHangSx);

$queryKhuyenmai = "select * from khuyenmai";
$queryKhuyenMai1 = mysqli_query($conn,$queryKhuyenmai);

$id = $_GET["MaSanPham"];
$sql = "select * from sanpham where MaSanPham = '$id'";
$query = mysqli_query($conn, $sql);
while ( $data = mysqli_fetch_array($query) ) {
    $masanpham = $data["MaSanPham"];
    $tensanpham = $data["TenSanPham"];
    $hinhanh = $data["HinhAnh"];
    $gia = $data["Gia"];
    $kichthuoc = $data["KichThuoc"];
    $mausac = $data["MauSac"];
    $ngaynhap = $data["NgayNhap"];
    $soluongton = $data["SoLuongTon"];
    $soluongban = $data["SoLuongBan"];
    $soluotxem = $data["SoLuotXem"];
    $mota = $data["MoTa"];
    $tinhtrang = $data["TinhTrang"];

}

if (isset($_POST["save"])) {
    $tensanpham = $_POST["TenSanPham"];
    $gia = $_POST["Gia"];
    $kichthuoc = $_POST["KichThuoc"];
    $mausac = $_POST["MauSac"];
    $ngaynhap = $_POST["NgayNhap"];
//    $soluongtonn = $_POST["SoLuongTon"];
//    $soluongbann = $_POST["SoLuongBan"];
//    $soluotxemm = $_POST["SoLuotXem"];
    $mota = $_POST["MoTa"];
    $tinhtrang = $_POST["tinhtrang"];
    $loaisp = $_POST["loaisp"];
    $hangsx = $_POST["hangsx"];
    $km = $_POST["km"];

    if(isset($_FILES['HinhAnh'])) {
        $hinhanh = $_FILES["HinhAnh"];
        $file_name = $_FILES['HinhAnh']['name'];
        $file_size = $_FILES['HinhAnh']['size'];
        $file_tmp = $_FILES['HinhAnh']['tmp_name'];
        $error = $_FILES['HinhAnh']['error'];


        if ($error === 0) {
            if ($file_size > (5 * 1024 * 1024)) {
                echo '<script>alert("xin lỗi, File bạn chọn to thế!!")</script>';
            } else {
                $img_ex = pathinfo($file_name, PATHINFO_EXTENSION);
                $img_ex_lc = strtolower($img_ex);

                $allowed_exs = array("jpg", "jpeg", "png");

                if (in_array($img_ex_lc, $allowed_exs)) {
                    $hinhanh = uniqid("SP-", true) . '.' . $img_ex_lc;
                    $img_upload_path = '../images/sanpham/' . $hinhanh;
                    move_uploaded_file($file_tmp, $img_upload_path);

                if(empty($_POST['Gia']) || empty($_POST['KichThuoc']) || empty($_POST['NgayNhap']) || empty($_POST['loaisp']) || empty($_POST['hangsx']) || empty($_POST['tinhtrang']) || empty($_POST['MoTa'])) {
                    //&& empty($_POST['ngaynhap']) && empty($_POST['Loaisp']) && empty($_POST['Hangsx']) && empty($_POST['tinhtrang']) && empty($_POST['mota'])
                    echo '<script>alert("Xin kiểm tra lại, thiếu 1 trong số các trường thông tin bắt buộc!!")</script>';
                }else {
//                NgayNhap = '$ngaynhap', SoLuongTon = '$soluongton', SoLuongBan = '$soluongban', SoLuotXem = '$soluotxem',
                    $Update = "update sanpham set  TenSanPham = '$tensanpham', HinhAnh = '$hinhanh' , Gia = '$gia', KichThuoc = '$kichthuoc', MauSac = '$mausac', NgayNhap = '$ngaynhap', MoTa = '$mota', TinhTrang = '$tinhtrang', MaLoaiSanPham = '$loaisp', MaHangSanXuat = '$hangsx', Id_KhuyenMai = '$km' where MaSanPham = '$id'";
                    if (mysqli_query($conn, $Update)) {
                        echo '<script>alert ("Sửa Sản Phẩm thành công rùi đó!!HiHi")</script>';

                    } else {
                        echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
                    }
                }
                } else {

                    echo '<script>alert("Bạn không chọn đúng định dạng file rồi!!")</script>';

                }
            }
        }
    }
            if(empty($_POST['Gia']) || empty($_POST['KichThuoc']) || empty($_POST['NgayNhap']) || empty($_POST['loaisp']) || empty($_POST['hangsx']) || empty($_POST['tinhtrang']) || empty($_POST['MoTa'])) {
                //&& empty($_POST['ngaynhap']) && empty($_POST['Loaisp']) && empty($_POST['Hangsx']) && empty($_POST['tinhtrang']) && empty($_POST['mota'])
                echo '<script>alert("Xin kiểm tra lại, thiếu 1 trong số các trường thông tin bắt buộc!!")</script>';
            }else {

                $Update = "update sanpham set  TenSanPham = '$tensanpham', Gia = '$gia', KichThuoc = '$kichthuoc', MauSac = '$mausac',NgayNhap = '$ngaynhap', MoTa = '$mota', TinhTrang = '$tinhtrang', MaLoaiSanPham = '$loaisp', MaHangSanXuat = '$hangsx', Id_KhuyenMai = '$km' where MaSanPham = '$id'";
                if (mysqli_query($conn, $Update)) {
                    echo '<script>alert ("Sửa Sản Phẩm thành công rùi đó!!HiHi")</script>';

                } else {
                    echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
                }
            }

}



?>

<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Sửa thông tin sản phẩm
                        <span class="tools pull-right">
                                <a class="fa fa-chevron-down" href="javascript:;"></a>
                             </span>
                    </header>
                    <div class="panel-body">
                        <div class="form">
                            <form class="cmxform form-horizontal " id="signupForm" method="post" action="" enctype="multipart/form-data">
                                <div class="form-group ">
                                    <label for="firstname" class="control-label col-lg-3">Mã Sản Phẩm</label>
                                    <div class="col-lg-6">
                                        <input disabled class=" form-control" id="firstname" name="MaSanPham" value="<?php echo $masanpham ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Tên Sản Phẩm</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="TenSanPham" value="<?php echo $tensanpham ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Ảnh Cũ</label>
                                    <div class="col-lg-6">
                                        <?php
                                        $sql = "SELECT * FROM sanpham where MaSanPham = '$id'";
                                        $res = mysqli_query($conn,  $sql);
                                        if (mysqli_num_rows($res) > 0) {
                                            while ($row = mysqli_fetch_assoc($res)) {
                                                ?>
                                                <!--                                        <input class="form-control " id="username" name="logo" value="--><?php //echo $logo ?><!--" type="text">-->
                                                <img src="../images/sanpham/<?php echo $row['HinhAnh'] ?>" width="200" height="200">
                                            <?php } }?>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Ảnh Mới</label>
                                    <div class="col-lg-6">
                                        <input name="HinhAnh" type="file">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Giá</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="Gia" value="<?php echo $gia ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Kích Thước</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="KichThuoc" value="<?php echo $kichthuoc ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Màu Sắc</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="MauSac" value="<?php echo $mausac ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Ngày Nhập</label>
                                    <div class="col-lg-6">
                                        <input class="form-control " id="username" name="NgayNhap" value="<?php echo $ngaynhap ?>" type="date">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Số Lượng Tồn</label>
                                    <div class="col-lg-6">
                                        <input disabled class="form-control " id="username" name="SoLuongTon" value="<?php echo $soluongton ?>" type="number">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Số Lượng Bán</label>
                                    <div class="col-lg-6">
                                        <input disabled class="form-control " id="username" name="SoLuongBan" value="<?php echo $soluongban ?>" type="number">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Số Lượt Xem</label>
                                    <div class="col-lg-6">
                                        <input disabled class="form-control " id="username" name="SoLuotXem" value="<?php echo $soluotxem ?>" type="number">
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Mô Tả</label>
                                    <div class="col-lg-6">
                                        <textarea class="form-control" name="MoTa" ><?php echo $mota?></textarea>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Tình Trạng</label>
                                    <div class="col-lg-6">
<!--                                        <input class="form-control " id="username" name="MoTa" value="--><?php //echo $mota ?><!--" type="text">-->
                                        <select name="tinhtrang" class="form-control m-bot15">
                                            <option <?php if($tinhtrang == ''){echo("selected");}?>>--</option>
                                            <option <?php if($tinhtrang == 'hoạt động'){echo("selected");}?>>hoạt động</option>
                                            <option <?php if($tinhtrang == 'không hoạt động'){echo("selected");}?>>không hoạt động</option>

                                        </select>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Loại Sản Phẩm</label>
                                    <div class="col-lg-6">
                                        <!--                                        <input class="form-control " id="username" name="MoTa" value="--><?php //echo $mota ?><!--" type="text">-->
                                        <select name="loaisp" class="form-control m-bot15">
<!--                                            <option value="unselect" selected>Lựa chọn nhà cung cấp</option>-->
                                            <?php
                                                while ($rowLoaiSp = mysqli_fetch_array($queryLoaisp1)){
                                            ?>
                                                <option value="<?php echo $rowLoaiSp['MaLoaiSanPham'];?>"><?php echo $rowLoaiSp["TenLoaiSanPham"];?></option>

                                            <?php } ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Hãng Sản Xuất</label>
                                    <div class="col-lg-6">
                                        <!--                                        <input class="form-control " id="username" name="MoTa" value="--><?php //echo $mota ?><!--" type="text">-->
                                        <select name="hangsx" class="form-control m-bot15">
<!--                                            <option value="unselect" selected>Lựa chọn hãng sản xuất</option>-->
                                            <?php
                                            while ($rowHangsx = mysqli_fetch_array($queryhangsx1)){
                                                ?>
                                                <option value="<?php echo $rowHangsx['MaHangSanXuat'];?>"><?php echo $rowHangsx["TenHangSanXuat"];?></option>

                                            <?php } ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="username" class="control-label col-lg-3">Lựa chọn Khuyến Mãi</label>
                                    <div class="col-lg-6">
                                        <!--                                        <input class="form-control " id="username" name="MoTa" value="--><?php //echo $mota ?><!--" type="text">-->
                                        <select name="km" class="form-control m-bot15">
<!--                                            <option value="unselect" selected>Lựa chọn hãng sản xuất</option>-->
                                            <?php
                                            while ($rowkm = mysqli_fetch_array($queryKhuyenMai1)){
                                                ?>
                                                <option value="<?php echo $rowkm['Id_KhuyenMai'];?>"><?php echo $rowkm["TenKhuyenMai"];?></option>

                                            <?php } ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-6">
                                        <input class="btn btn-primary" name="save" type="submit" value="Save">
                                        <a href="QLSanPham.php"><button class="btn btn-default"  type="button" value="Cancel">Cancel</button></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</section>
