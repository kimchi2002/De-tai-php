<?php
include '../connect/conectdb.php';
include 'header.php';
include 'phanquyenNhanVien.php';
?>


<section id="main-content">
    <section class="wrapper">
        <div class="table-agile-info">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Loại Sản Phẩm
                </div>

                <form action="" method="get">
                    <table>
                        <tr>
                            <td>
                                <input type="hidden" name = "option" value="Customer">
                                <input type="text" name="search">
                            </td>
                            <td>
                                &nbsp;&nbsp; <input type="submit" value="search">&nbsp;&nbsp;
                                <input type="button" value="All" onclick="window.location.href='./LoaiSp.php'">
                            </td>
                        </tr>
                    </table>
<!--                    <input type="hidden" name="Stt" value="--><?php //echo $stt ?><!--">-->
                </form>
                <form method="POST" action="">
                <a style="background-color: #80d3d9; text-align: center" class="btn btn-default" id="openBtn">Thêm</a>
                <div id="modal-content" class="modal fade"  role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">×</button>
                                <h3 style="text-align: center; color: blue">Thêm Thông Tin Loại Sản Phẩm</h3>
                            </div>
                                <div class="modal-body">
                                    <table>
                                        <tr>
                                            <th>Mã Loại Sản phẩm</th><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td>
                                            <td>
                                                <input name="MaLoaiSp" type="text" id="txtname" value="" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Tên Loại Sản phẩm</th><td> </td>
                                            <td>
                                                <input name="TenLoaiSp" type="text" id="txtname" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Tình trạng</th><td> </td>
                                            <td>
                                                <select name="tinhtrang" class="form-control m-bot15">
                                                    <option>hoạt động</option>
                                                    <option>không hoạt động</option>
                                                </select>
                                            </td>
                                        </tr>

                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <a href="#" class="btn" data-dismiss="modal">Close</a>
                                    <input name="save" class="btn btn-primary" type="submit" value="Save">
                                </div>

                        </div>
                    </div>
                </div>
                </form>
                <?php

                $MaLoaiSanPham="";
                $TenLoaiSanPham="";
                $TinhTrang="";

                if(isset($_POST['save'])) {

                    if (isset($_POST['MaLoaiSp'])) {
                        $MaLoaiSanPham = $_POST['MaLoaiSp'];
                    }
                    if (isset($_POST['TenLoaiSp'])) {
                        $TenLoaiSanPham = $_POST['TenLoaiSp'];
                    }
                    if (isset($_POST['tinhtrang'])) {
                        $TinhTrang = $_POST['tinhtrang'];
                    }


                    if (isset($MaLoaiSanPham) && isset($TenLoaiSanPham)) {
                        $sql = "select * from loaisanpham where MaLoaiSanPham = '$MaLoaiSanPham'";
                        $check = $conn->query($sql);
                        $sql1 = "select * from loaisanpham where TenLoaiSanPham = '$TenLoaiSanPham'";
                        $check1 = $conn->query($sql1);


                        if (mysqli_num_rows($check) > 0) {
                            echo '<script>alert ("Mã sản phẩm này có người dùng r đấy")</script>';
                        } else if (mysqli_num_rows($check1) > 0) {
                            echo '<script>alert ("Tên loại sản phẩm này tồn tại rồi!!!")</script>';
                        } else {
                            $Insert = "insert into loaisanpham values('$MaLoaiSanPham','$TenLoaiSanPham','$TinhTrang')";
                            if (mysqli_query($conn, $Insert)) {
                                // $kq = $conn->query($Insert);
                                // $conn->close();
                                echo '<script>alert ("Tạo Sản phẩm thành công rùi đó!!HiHi")</script>';
                                //      $conn->close();
                            } else {
                                echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
                            }
                        }
                    }
                }

                ?>

                <br>

                <div class="table-responsive">
                    <table class="table table-striped b-t b-light">
                        <thead>
                        <tr>
<!--                            <th>STT</th>-->
                            <th>Mã Loại Sản Phẩm</th>
                            <th>Tên Loại Sản Phẩm</th>
                            <th>Tình trạng</th>
                            <th>Lựa chọn</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php

                        $result = mysqli_query($conn, 'select count(MaLoaiSanPham) as total from loaisanpham');
                        $row = mysqli_fetch_assoc($result);
                        $total_records = $row['total'];
//                        if($total_records == 0){
//                            echo '<td></td>';
//                        }


                        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
                        $current_page = isset($_GET['loaisp']) ? $_GET['loaisp'] : 1;
                        $limit = 3;

                        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
                        // tổng số trang
                        $total_page = ceil($total_records / $limit);

                        // Giới hạn current_page trong khoảng 1 đến total_page
                        if ($current_page > $total_page){
                            $current_page = $total_page;
                        }
                        else if ($current_page < 1){
                            $current_page = 1;
                        }

                        // Tìm Start
                        $start = ($current_page - 1) * $limit;

                        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
                        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
                        if(ISSET($_GET['search'])&&!empty($_GET['search'])){
                            $key = addslashes($_GET['search']);
                            //    //`MaLoaiTaiKhoan` = 1 and
                            $result = mysqli_query($conn, "SELECT * FROM loaisanpham where (`MaLoaiSanPham` LIKE '%$key%' OR `TenLoaiSanPham` LIKE '%$key%')");
                        } else {
                            //    $sql = "SELECT * FROM taikhoan  where (`TinhTrang` = 'hoạt động') and (LIMIT '$start_from', '$per_page_record')";

                            $result = mysqli_query($conn, "SELECT * FROM loaisanpham order by MaLoaiSanPham DESC LIMIT $start, $limit  ");}

                        ?>

                        <?php
                        // PHẦN HIỂN THỊ TIN TỨC
                        // BƯỚC 6: HIỂN THỊ DANH SÁCH TIN TỨC
                        while ($row = mysqli_fetch_assoc($result)) {
                            // echo '<li>' . $row['MaTaiKhoan'] . '</li>';
                            echo '<tr>';
//                            echo '<td>' . $row['Stt'] . '</td>';
                            echo '<td>' . $row['MaLoaiSanPham'] . '</td>';
                            echo '<td>' . $row['TenLoaiSanPham'] . '</td>';
                            echo '<td>' . $row['TinhTrang'] . '</td>';
//                            echo '<td>' . '<a class="btn btn-sm btn-danger" href=""><i class="fas fa-toggle-off"></i> </a>' . '</td>';
                            //href="LoaiSp.php?MaLoaiSanPham=' . $row['MaLoaiSanPham'] . '"
                            echo '<td>' . '<a href="/BaiTapLon_PHP/WebBanHang/admin/SuaLoaiSp.php?MaLoaiSanPham=' . $row['MaLoaiSanPham'] . ' " <button type="button" class="btn btn-info">Sửa</button> </a>'
                                .'<a href="/BaiTapLon_PHP/WebBanHang/admin/Delete_Kh.php?MaLoaiSanPham=' . $row['MaLoaiSanPham'] . ' " onclick="return ConfirmDelete();" <button type="button" class="btn btn-danger">Xóa</button> </a>' . '</td>';


                                echo '</tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>

            </div>
            <nav style="text-align: center" aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item">
                        <?php echo '<a class="page-link" href="LoaiSp.php?loaisp='.($current_page-1).'" aria-label="Previous">Previous</a>' ?>
                    </li>
                    <?php
                    for ($i = 1; $i <= $total_page; $i++){
                        // Nếu là trang hiện tại thì hiển thị thẻ span
                        // ngược lại hiển thị thẻ a
                        if ($i == $current_page){
                            echo '<li class="page-item"><a class="page-link" href="LoaiSp.php?loaisp=">'.$i.'</a></li>';
                        }
                    }
                    ?>
                    <li class="page-item">
                        <?php echo '<a class="page-link" href="LoaiSp.php?loaisp='.($current_page+1).'" aria-label="Next">Next</a>' ?>

                    </li>
                </ul>
            </nav>
            <script>

                function ConfirmDelete()
                {
                  // var x = confirm("Do you really want to delete?");
                   var x;
                   if (confirm("Are you sure?") ==true) {
                       x = 'xóa đc r đấy';
                   }else{
                       x = "okee nếu k muốn thì thôi!!"
                   }
                   return x;
                   // alert("này có muốn xóa thật không đấy!!!")
                }


                    $("#openBtn").click(function () {
                        $("#modal-content").modal({
                            show: true
                        });
                    });

            </script>
        </div>
    </section>
</section>

