<?php
include '../connect/conectdb.php';
include 'header.php';
include 'phanquyenNhanVien.php';
?>

<section id="main-content">
    <section class="wrapper">
        <div class="table-agile-info">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Danh Sách Khuyến Mãi
                </div>

                <form action="" method="get">
                    <table>
                        <tr>
                            <td>
                                <input type="hidden" name = "option" value="Customer">
                                <input type="text" name="search">
                            </td>
                            <td>
                                &nbsp;&nbsp; <input type="submit" value="search">&nbsp;&nbsp;
                                <input type="button" value="All" onclick="window.location.href='./KhuyenMai.php'">
                            </td>
                        </tr>
                    </table>
                    <!--                    <input type="hidden" name="Stt" value="--><?php //echo $stt ?><!--">-->
                </form>
                <form method="POST" action="" enctype="multipart/form-data">
                    <a style="background-color: #80d3d9; text-align: center" class="btn btn-default" id="openBtn">Thêm mới</a>
                    <div id="modal-content" class="modal fade"  role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">×</button>
                                    <h3 style="text-align: center; color: blue">Thêm Chương Trình Khuyến Mãi</h3>
                                </div>
                                <div class="modal-body">
                                    <table>
                                        <tr>
                                            <th>Tên Chương Trình &nbsp;&nbsp;</th>
                                            <td>
                                                <input name="TenKhuyenMai" type="text" value="" size="50"/>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Loại Chương trình</th>
                                            <td>
                                                <select name="Loaichuongtrinh">

                                                    <option>--</option>
                                                    <option>Giảm theo số tiền</option>
                                                    <option>Giảm theo phần trăm</option>
                                                </select>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Mức Giảm</th>
                                            <td>
                                                <input name="mucgiam" type="text" size="50" placeholder="VNĐ or %"/>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>

                                        <tr>
                                            <th>Thời gian bắt đầu</th>
                                            <td>
                                                <input type="date" name="ThoiGianbd">
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Thời Gian Kết Thúc</th>
                                            <td>
                                                <input type="date" name="ThoiGiankt">
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>

                                        <tr>
                                            <th>Số lượng sp áp dụng</th>
                                            <td>
                                                <input type="text" name="soluongsp" size="50">
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>

                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <a href="#" class="btn" data-dismiss="modal">Close</a>
                                    <input name="save" class="btn btn-primary" type="submit" value="Save">
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
                <?php

                $Tenchuongtrinh="";
                $Loaichuongtrinh="";
                $Mucgiam="";
                $thoigianbd="";
                $thoigiankt="";
                $Soluong="";

                if(isset($_POST['save'])) {

                    if (isset($_POST['TenKhuyenMai'])) {
                        $Tenchuongtrinh = $_POST['TenKhuyenMai'];
                    }
                    if (isset($_POST['Loaichuongtrinh'])) {
                        $Loaichuongtrinh = $_POST['Loaichuongtrinh'];
                    }
                    if (isset($_POST['mucgiam'])) {
                        $Mucgiam = $_POST['mucgiam'];
                    }
                    if (isset($_POST['ThoiGianbd'])) {
                        $thoigianbd = $_POST['ThoiGianbd'];
                    }
                    if (isset($_POST['ThoiGiankt'])) {
                        $thoigiankt = $_POST['ThoiGiankt'];
                    }
                    if (isset($_POST['soluongsp'])) {
                        $Soluong = $_POST['soluongsp'];
                    }


                    if (isset($Tenchuongtrinh)) {
                        $sql = "select * from khuyenmai where TenKhuyenMai = '$Tenchuongtrinh'";
                        $check = $conn->query($sql);

                        if (mysqli_num_rows($check) > 0) {
                            echo '<script>alert ("Tên khuyến mãi này có rồi!!")</script>';
                        }else if(empty($_POST["mucgiam"]) || empty($_POST["TenKhuyenMai"]) || empty($_POST["ThoiGianbd"]) || empty($_POST["ThoiGiankt"]) || empty($_POST["soluongsp"])){
                            echo '<script>alert("Xin kiểm tra lại, thiếu 1 trong số các trường thông tin!!")</script>';
                        } else {
                            $Insert = "insert into khuyenmai values('','$Tenchuongtrinh','$Loaichuongtrinh','$Mucgiam','$thoigianbd','$thoigiankt','$Soluong')";
                            if (mysqli_query($conn, $Insert)) {
                                // $kq = $conn->query($Insert);
                                // $conn->close();
                                echo '<script>alert ("Tạo Sản phẩm thành công rùi đó!!HiHi")</script>';
                                //      $conn->close();
                            } else {
                                echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
                            }
                        }

                    }
                }

                ?>

                <br>

                <div class="table-responsive">
                    <table class="table table-striped b-t b-light">
                        <thead>
                        <tr>
                            <th>Mã Khuyến Mãi</th>
                            <th>Tên Khuyến Mãi</th>
                            <th>Loại Chương Trình</th>
<!--                            <th>Áp dụng Cho</th>-->
                            <th>Mức Giảm</th>
                            <th>Thời Gian Bắt Đầu</th>
                            <th>Thời Gian Kết Thúc</th>
                            <th>Số lượng Áp Dụng</th>
                            <th>Hành Động</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php

                        $result = mysqli_query($conn, 'select count(Id_KhuyenMai) as total from khuyenmai');
                        $row = mysqli_fetch_assoc($result);
                        $total_records = $row['total'];

                        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
                        $current_page = isset($_GET['khuyenmai']) ? $_GET['khuyenmai'] : 1;
                        $limit = 3;

                        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
                        // tổng số trang
                        $total_page = ceil($total_records / $limit);

                        // Giới hạn current_page trong khoảng 1 đến total_page
                        if ($current_page > $total_page){
                            $current_page = $total_page;
                        }
                        else if ($current_page < 1){
                            $current_page = 1;
                        }

                        // Tìm Start
                        $start = ($current_page - 1) * $limit;

                        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
                        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
                        if(ISSET($_GET['search'])&&!empty($_GET['search'])){
                            $key = addslashes($_GET['search']);
                            //    //`MaLoaiTaiKhoan` = 1 and
                            $result = mysqli_query($conn, "SELECT * FROM khuyenmai where (`Id_KhuyenMai` LIKE '%$key%' OR `TenKhuyenMai` LIKE '%$key%' OR `MucGiam` LIKE '%$key%' OR `ThoiGianBD` LIKE '%$key%' OR `ThoiGianKT` LIKE '%$key%' )");
                        } else {
                            //    $sql = "SELECT * FROM taikhoan  where (`TinhTrang` = 'hoạt động') and (LIMIT '$start_from', '$per_page_record')";

                            $result = mysqli_query($conn, "SELECT * FROM khuyenmai order by Id_KhuyenMai DESC LIMIT $start, $limit  ");}

                        ?>

                        <?php
                        // PHẦN HIỂN THỊ TIN TỨC
                        // BƯỚC 6: HIỂN THỊ DANH SÁCH TIN TỨC
                        while ($row = mysqli_fetch_assoc($result)) {
                            // echo '<li>' . $row['MaTaiKhoan'] . '</li>';
                            echo '<tr>';
//                            echo '<td>' . $row['Stt'] . '</td>';
                            echo '<td>' . $row['Id_KhuyenMai'] . '</td>';
                            echo '<td>' . $row['TenKhuyenMai'] . '</td>';
                            echo '<td>' . $row['LoaiKhuyenMai'] . '</td>';
//                            echo '<td>' . $row['ApDung'] . '</td>';
                            echo '<td>' . $row['MucGiam'] . '</td>';
                            echo '<td>' . $row['ThoiGianBD'] . '</td>';
                            echo '<td>' . $row['ThoiGianKT'] . '</td>';
                            echo '<td>' . $row['SoLuongSpApDung'] . '</td>';
                           // echo '<td>' . "<img src='../images/hangsanxuat/".$row["Logo"]."' width=100, height:100>" . '</td>';
                            // echo '<td>' . $row['Logo'] . '</td>';
                          //  echo '<td>' . $row['TinhTrang'] . '</td>';
//                            echo '<td>' . '<a class="btn btn-sm btn-danger" href=""><i class="fas fa-toggle-off"></i> </a>' . '</td>';
                            //href="LoaiSp.php?MaLoaiSanPham=' . $row['MaLoaiSanPham'] . '"


                            echo '<td>' . '<a href="/BaiTapLon_PHP/WebBanHang/admin/SuaKhuyenMai.php?Id_KhuyenMai=' . $row['Id_KhuyenMai'] . ' " <button type="button" class="btn btn-info">Sửa</button> </a>'
                                .'<a href="/BaiTapLon_PHP/WebBanHang/admin/Delete_Kh.php?Id_KhuyenMai=' . $row['Id_KhuyenMai'] . ' " onclick="return ConfirmDelete();" <button type="button" class="btn btn-danger">Xóa</button> </a>' . '</td>';


                            echo '</tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>

            </div>
            <nav style="text-align: center" aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item">
                        <?php echo '<a class="page-link" href="KhuyenMai.php?khuyenmai='.($current_page-1).'" aria-label="Previous">Previous</a>' ?>
                    </li>
                    <?php
                    for ($i = 1; $i <= $total_page; $i++){
                        // Nếu là trang hiện tại thì hiển thị thẻ span
                        // ngược lại hiển thị thẻ a
                        if ($i == $current_page){
                            echo '<li class="page-item"><a class="page-link" href="KhuyenMai.php?khuyenmai=">'.$i.'</a></li>';
                        }
                    }
                    ?>
                    <li class="page-item">
                        <?php echo '<a class="page-link" href="KhuyenMai.php?khuyenmai='.($current_page+1).'" aria-label="Next">Next</a>' ?>

                    </li>
                </ul>
            </nav>
            <script>

                function ConfirmDelete()
                {
                    // var x = confirm("Do you really want to delete?");
                    var x;
                    if (confirm("Are you sure?") ==true) {
                        x = 'xóa đc r đấy';
                    }else{
                        x = "okee nếu k muốn thì thôi!!"
                    }
                    return x;
                    // alert("này có muốn xóa thật không đấy!!!")
                }


                $("#openBtn").click(function () {
                    $("#modal-content").modal({
                        show: true
                    });
                });

            </script>
        </div>
    </section>
</section>

