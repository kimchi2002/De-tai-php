<?php
include '../connect/conectdb.php';
include 'header.php';
include 'phanquyenNhanVien.php';
?>


<?php
    $queryLoaisp = "select * from loaisanpham";
    $queryLoaisp1 = mysqli_query($conn,$queryLoaisp);

    $queryHangSx = "select * from hangsanxuat";
    $queryhangsx1 = mysqli_query($conn,$queryHangSx);

    $queryKhuyenmai = "select * from khuyenmai";
    $queryKhuyenMai1 = mysqli_query($conn,$queryKhuyenmai);

?>

<section id="main-content">
    <section class="wrapper">
        <div class="table-agile-info">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Quản Lý Sản Phẩm
                </div>

                <form action="" method="get">
                    <table>
                        <tr>
                            <td>
                                <input type="hidden" name = "option" value="Customer">
                                <input type="text" name="search">
                            </td>
                            <td>
                                &nbsp;&nbsp; <input type="submit" value="search">&nbsp;&nbsp;
                                <input type="button" value="All" onclick="window.location.href='./HangSanXuat.php'">
                            </td>
                        </tr>
                    </table>
                    <!--                    <input type="hidden" name="Stt" value="--><?php //echo $stt ?><!--">-->
                </form>
                <form method="POST" action="" enctype="multipart/form-data">
                    <a style="background-color: #80d3d9; text-align: center" class="btn btn-default" id="openBtn">Thêm mới sản phẩm</a>
                    <div id="modal-content" class="modal fade"  role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">×</button>
                                    <h3 style="text-align: center; color: blue">Thêm Sản Phẩm</h3>
                                </div>
                                <div class="modal-body">
                                    <table>
                                        <tr>
                                            <th>Mã Sản Phẩm</th><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td>
                                            <td>
                                                <input name="Masanpham" type="text" id="txtname" value="" size="50"/>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Tên Sản Phẩm</th><td> </td>
                                            <td>
                                                <input name="Tensanpham" type="text" id="txtname" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Hình Ảnh</th><td> </td>
                                            <td>
                                                <input name="hinhanh" type="file" id="txtname" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Giá</th><td> </td>
                                            <td>
                                                <input name="gia" type="text" placeholder="VND" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Kích Thước</th><td> </td>
                                            <td>
                                                <input name="kichthuoc" type="text" id="txtname" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Màu Sắc</th><td> </td>
                                            <td>
                                                <input name="mausac" type="text" id="txtname" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Ngày Nhập</th><td> </td>
                                            <td>
                                                <input name="ngaynhap" type="date" id="txtname" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Số Lượng Tồn</th><td> </td>
                                            <td>
                                                <input name="soluongton" type="number" id="txtname" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Số Lượng Bán</th><td> </td>
                                            <td>
                                                <input name="soluongban" type="number" id="txtname" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Số Lượt Xem</th><td> </td>
                                            <td>
                                                <input name="soluotxem" type="number" id="txtname" size="50" />
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Mô Tả</th><td> </td>
                                            <td>
                                                <textarea name="mota" rows="4" cols="50"></textarea>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Tình trạng</th><td> </td>
                                            <td>
                                                <select name="tinhtrang" class="form-control m-bot15">
                                                    <option>hoạt động</option>
                                                    <option>không hoạt động</option>
                                                </select>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Loại Sản Phẩm</th><td> </td>
                                            <td>
                                                <select name="Loaisp" class="form-control m-bot15">
                                                    <option value="unselect" selected>Lựa chọn nhà cung cấp</option>
                                                    <?php
                                                        while ($rowLoaiSp = mysqli_fetch_array($queryLoaisp1)){
                                                    ?>
                                                        <option value="<?php echo $rowLoaiSp['MaLoaiSanPham'];?>"><?php echo $rowLoaiSp["TenLoaiSanPham"];?></option>

                                                    <?php } ?>
                                                </select>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Hãng Sản Xuất</th><td> </td>
                                            <td>
                                                <select name="Hangsx" class="form-control m-bot15">
                                                    <option value="unselect" selected>Lựa chọn Hãng Sản Xuất</option>
                                                    <?php
                                                        while ($rowHangsx = mysqli_fetch_array($queryhangsx1)){
                                                    ?>
                                                            <option value="<?php echo $rowHangsx['MaHangSanXuat'];?>"><?php echo $rowHangsx["TenHangSanXuat"];?></option>


                                                        <?php } ?>
                                                </select>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>
                                        <tr>
                                            <th>Khuyến Mãi</th><td> </td>
                                            <td>
                                                <select name="khuyenmai" class="form-control m-bot15">
                                                    <option value="unselect" selected>Lựa chọn Khuyến Mãi</option>
                                                    <?php
                                                    while ($rowkm = mysqli_fetch_array($queryKhuyenMai1)){
                                                        ?>
                                                        <option value="<?php echo $rowkm['Id_KhuyenMai'];?>"><?php echo $rowkm["TenKhuyenMai"];?></option>


                                                    <?php } ?>
                                                </select>
                                            </td>
                                        </tr><tr><td>&nbsp;</td></tr>

                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <a href="#" class="btn" data-dismiss="modal">Close</a>
                                    <input name="save" class="btn btn-primary" type="submit" value="Save">
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
                <?php

                $MaSanPham="";
                $TenSanPham="";
                $HinhAnh="";
                $Gia=""; $Kichthuoc = ""; $MauSac=""; $NgayNhap=""; $Soluongton = ""; $SoLuongBan=""; $SoLuotXem=""; $MoTa=""; $TinhTrang="";

                $LoaiSp=""; $HangSx="";$KhuyenMai="";

                if(isset($_POST['save']) && isset($_FILES['hinhanh'])) {

                    if (isset($_POST['Masanpham'])) {
                        $MaSanPham = $_POST['Masanpham'];
                    }
                    if (isset($_POST['Tensanpham'])) {
                        $TenSanPham = $_POST['Tensanpham'];
                    }
                    if (isset($_POST['hinhanh'])) {
                        $HinhAnh = $_FILES['hinhanh'];
                    }
                    if (isset($_POST['gia'])) {
                        $Gia = $_POST['gia'];
                    }if (isset($_POST['kichthuoc'])) {
                        $Kichthuoc = $_POST['kichthuoc'];
                    }if (isset($_POST['mausac'])) {
                        $MauSac = $_POST['mausac'];
                    }if (isset($_POST['ngaynhap'])) {
                        $NgayNhap = $_POST['ngaynhap'];
                    }if (isset($_POST['soluongton'])) {
                        $Soluongton = $_POST['soluongton'];
                    }if (isset($_POST['soluongban'])) {
                        $SoLuongBan = $_POST['soluongban'];
                    }if (isset($_POST['soluotxem'])) {
                        $SoLuotXem = $_POST['soluotxem'];
                    }
                    if (isset($_POST['mota'])) {
                        $MoTa = $_POST['mota'];
                    }if (isset($_POST['tinhtrang'])) {
                        $TinhTrang = $_POST['tinhtrang'];
                    }
                    if (isset($_POST['Loaisp'])) {
                        $LoaiSp = $_POST['Loaisp'];
                    }
                    if (isset($_POST['Hangsx'])) {
                        $HangSx = $_POST['Hangsx'];
                    }
                    if (isset($_POST['khuyenmai'])) {
                        $KhuyenMai = $_POST['khuyenmai'];
                    }

                    $file_name = $_FILES['hinhanh']['name'];
                    $file_size = $_FILES['hinhanh']['size'];
                    $file_tmp = $_FILES['hinhanh']['tmp_name'];
                    $error = $_FILES['hinhanh']['error'];

                    if ($error === 0) {
                        if ($file_size > (5 * 1024 * 1024)) {
                            echo '<script>alert("xin lỗi, File bạn chọn to thế!!")</script>';
                        } else {
                            $img_ex = pathinfo($file_name, PATHINFO_EXTENSION);
                            $img_ex_lc = strtolower($img_ex);

                            $allowed_exs = array("jpg", "jpeg", "png");

                            if (in_array($img_ex_lc, $allowed_exs)) {
                                $HinhAnh = uniqid("SP-", true) . '.' . $img_ex_lc;
                                $img_upload_path = '../images/sanpham/' . $HinhAnh;
                                move_uploaded_file($file_tmp, $img_upload_path);

                                if (isset($MaSanPham) && isset($TenSanPham)) {
                                    $sql = "select * from sanpham where MaSanPham = '$MaSanPham'";
                                    $check = $conn->query($sql);
                                    $sql1 = "select * from sanpham where TenSanPham = '$TenSanPham'";
                                    $check1 = $conn->query($sql1);
                                    if (mysqli_num_rows($check) > 0) {
                                        echo '<script>alert ("Mã sản phẩm này có người dùng r đấy")</script>';
                                    } else if (mysqli_num_rows($check1) > 0) {
                                        echo '<script>alert ("Tên sản phẩm này tồn tại rồi!!!")</script>';
                                    }
                                    else if(empty($_POST['gia']) && empty($_POST['kichthuoc']) && empty($_POST['ngaynhap']) && empty($_POST['Loaisp']) && empty($_POST['Hangsx']) && empty($_POST['tinhtrang']) && empty($_POST['mota'])){
                                        //&& empty($_POST['ngaynhap']) && empty($_POST['Loaisp']) && empty($_POST['Hangsx']) && empty($_POST['tinhtrang']) && empty($_POST['mota'])
                                        echo '<script>alert("Xin kiểm tra lại, thiếu 1 trong số các trường thông tin bắt buộc!!")</script>';
                                    }
                                else {
                                        $Insert = "insert into sanpham values('$MaSanPham','$TenSanPham','$HinhAnh','$Gia','$Kichthuoc','$MauSac','$NgayNhap','$Soluongton','$SoLuongBan','$SoLuotXem','$MoTa','$TinhTrang','$LoaiSp','$HangSx','$KhuyenMai')";
                                        if (mysqli_query($conn, $Insert)) {
                                            echo '<script>alert ("Tạo Sản Phẩm thành công rùi đó!!HiHi")</script>';

                                        } else {
                                            echo '<script>alert("Có lỗi trong quá trình xử lý")</script>';
                                        }
                                    }
                                }

                            } else {

                                echo '<script>alert("Bạn không chọn đúng định dạng file rồi!!")</script>';

                            }
                        }
                    }
                }

                ?>

                <br>

                <div class="table-responsive">
                    <table class="table table-striped b-t b-light">
                        <thead>
                        <tr>
                            <th>Mã Sản Phẩm</th>
                            <th>Tên Sản Phẩm</th>
                            <th>Hình Ảnh</th>
                            <th>Giá</th>
                            <th>Kích Thước</th>
                            <th>Tình Trạng</th>
                            <th>loại sản phẩm</th>
                            <th>Tên Mã KM</th>
                            <th>Hành Động</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php

                        $result = mysqli_query($conn, 'select count(MaSanPham) as total from sanpham');
                        $row = mysqli_fetch_assoc($result);
                        $total_records = $row['total'];

                        // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
                        $current_page = isset($_GET['sanpham']) ? $_GET['sanpham'] : 1;
                        $limit = 3;

                        // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
                        // tổng số trang
                        $total_page = ceil($total_records / $limit);

                        // Giới hạn current_page trong khoảng 1 đến total_page
                        if ($current_page > $total_page){
                            $current_page = $total_page;
                        }
                        else if ($current_page < 1){
                            $current_page = 1;
                        }

                        // Tìm Start
                        $start = ($current_page - 1) * $limit;

                        // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
                        // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
                        if(ISSET($_GET['search'])&&!empty($_GET['search'])){
                            $key = addslashes($_GET['search']);
                            //    //`MaLoaiTaiKhoan` = 1 and
                            $result = mysqli_query($conn, "SELECT * FROM loaisanpham INNER JOIN sanpham on loaisanpham.MaLoaiSanPham = sanpham.MaLoaiSanPham INNER JOIN khuyenmai on sanpham.Id_KhuyenMai = khuyenmai.Id_KhuyenMai where (`MaSanPham` LIKE '%$key%' OR `TenSanPham` LIKE '%$key%' OR `Gia` LIKE '%$key%' OR `KichThuoc` LIKE '%$key%' OR `TenLoaiSanPham` LIKE '%$key%')");
                        } else {
                            //    $sql = "SELECT * FROM taikhoan  where (`TinhTrang` = 'hoạt động') and (LIMIT '$start_from', '$per_page_record')";

                            $result = mysqli_query($conn, "SELECT * FROM loaisanpham INNER JOIN sanpham on loaisanpham.MaLoaiSanPham = sanpham.MaLoaiSanPham INNER JOIN khuyenmai on sanpham.Id_KhuyenMai = khuyenmai.Id_KhuyenMai order by MaSanPham DESC LIMIT $start, $limit  ");}

                        ?>

                        <?php
                        // PHẦN HIỂN THỊ TIN TỨC
                        // BƯỚC 6: HIỂN THỊ DANH SÁCH TIN TỨC
                        while ($row = mysqli_fetch_assoc($result)) {
                            // echo '<li>' . $row['MaTaiKhoan'] . '</li>';
                            echo '<tr>';
                            echo '<td>' . $row['MaSanPham'] . '</td>';
                            echo '<td>' . $row['TenSanPham'] . '</td>';
                            echo '<td>' . "<img src='../images/sanpham/".$row["HinhAnh"]."' width=200, height:200>" . '</td>';
                            echo '<td>' . $row['Gia'] . '</td>';
                            echo '<td>' . $row['KichThuoc'] . '</td>';
                            echo '<td>' . $row['TinhTrang'] . '</td>';
                            echo '<td>' . $row['TenLoaiSanPham'] . '</td>';
                            echo '<td>' . $row['TenKhuyenMai'] . '</td>';

                            // echo '<td>' . $row['Logo'] . '</td>';
                          //  echo '<td>' . $row['TinhTrang'] . '</td>';
//                            echo '<td>' . '<a class="btn btn-sm btn-danger" href=""><i class="fas fa-toggle-off"></i> </a>' . '</td>';
                            //href="LoaiSp.php?MaLoaiSanPham=' . $row['MaLoaiSanPham'] . '"
                            echo '<td>' . '<a href="/BaiTapLon_PHP/WebBanHang/admin/SuaSanPham.php?MaSanPham=' . $row['MaSanPham'] . ' " <button type="button" class="btn btn-info">Sửa</button> </a>'
                                .'<a href="/BaiTapLon_PHP/WebBanHang/admin/Delete_Kh.php?MaSanPham=' . $row['MaSanPham'] . ' " onclick="return ConfirmDelete();" <button type="button" class="btn btn-danger">Xóa</button> </a>' . '</td>';


                            echo '</tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>

            </div>
            <nav style="text-align: center" aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item">
                        <?php echo '<a class="page-link" href="QLSanPham.php?sanpham='.($current_page-1).'" aria-label="Previous">Previous</a>' ?>
                    </li>
                    <?php
                    for ($i = 1; $i <= $total_page; $i++){
                        // Nếu là trang hiện tại thì hiển thị thẻ span
                        // ngược lại hiển thị thẻ a
                        if ($i == $current_page){
                            echo '<li class="page-item"><a class="page-link" href="QLSanPham.php?sanpham=">'.$i.'</a></li>';
                        }
                    }
                    ?>
                    <li class="page-item">
                        <?php echo '<a class="page-link" href="QLSanPham.php?sanpham='.($current_page+1).'" aria-label="Next">Next</a>' ?>

                    </li>
                </ul>
            </nav>
            <script>

                function ConfirmDelete()
                {
                    // var x = confirm("Do you really want to delete?");
                    var x;
                    if (confirm("Are you sure?") ==true) {
                        x = 'xóa đc r đấy';
                    }else{
                        x = "okee nếu k muốn thì thôi!!"
                    }
                    return x;
                    // alert("này có muốn xóa thật không đấy!!!")
                }


                $("#openBtn").click(function () {
                    $("#modal-content").modal({
                        show: true
                    });
                });

            </script>
        </div>
    </section>
</section>

