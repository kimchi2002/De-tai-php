<!DOCTYPE html>
<head>
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- bootstrap-css -->
    <link rel="stylesheet" href="../css/bootstrap.min.css" >
    <!-- //bootstrap-css -->
    <!-- Custom CSS -->
    <link href="../css/style.css" rel='stylesheet' type='text/css' />
    <link href="../css/style-responsive.css" rel="stylesheet"/>
    <!-- font CSS -->
    <link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- font-awesome icons -->
    <link rel="stylesheet" href="../css/font.css" type="text/css"/>
    <link href="../css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome icons -->
    <script src="../js/jquery2.0.3.min.js"></script>
    <script src="../js/sweetalert.min.js"></script>


    <?php
    session_start();
    include '../connect/conectdb.php';
    //include_once "./conectdb.php";
    $u="";
    $p="";
    if(isset($_POST['remember'])){
        setcookie("UserName",$_POST["UserName"],time()+86400);
        setcookie("PassWord",$_POST["PassWord"],time()+86400);
    }
    if (isset($_POST['login'])){
        $u = $_POST["UserName"];
        $p = $_POST["PassWord"];
        //làm sạch thông tin, xóa bỏ các tag html, ký tự đặc biệt
        //mà người dùng cố tình thêm vào để tấn công theo phương thức sql injection
        $u = strip_tags($u);
        $u = addslashes($u);
        $p = strip_tags($p);
        $p = addslashes($p);
        $p = md5($p);
        if(isset($u)&&isset($p)){
            $sql = "select * from  `taikhoan` where `TenDangNhap` = '$u' and `MatKhau` = '$p' and `TinhTrang` = 'hoạt động'";
            $query = mysqli_query($conn,$sql);
            $num_row = mysqli_num_rows($query);
            // echo $sql;
            if($num_row==0){
//                echo '<script>
//                    function (){
//                      Swal.fire({
//                          icon: "error",
//                          title: "Oops...",
//                          text: "Something went wrong!",
//                          footer: "<a href="">Why do I have this issue?</a>"
//                    })};</script>';

                echo '<script>alert ("Username or password incorrect")</script>';
                $_SESSION["UserName"]=NULL;
            }else{
                while ( $data = mysqli_fetch_array($query) ) {
                    $_SESSION["id"]=$data["MaTaiKhoan"];
                    $_SESSION["UserName"]=$data["fdc"];
                    $_SESSION["Password"]=$data["MatKhau"];
                    $_SESSION["TinhTrang"]=$data["TinhTrang"];
                    $_SESSION["TenHienThi"]=$data["TenHienThi"];
                    $_SESSION["Address"]=$data["DiaChi"];
                    $_SESSION["Phone"]=$data["DienThoai"];
                    $_SESSION["Email"]=$data["Email"];
                    $_SESSION["MaLoaiTaiKhoan"]=$data["MaLoaiTaiKhoan"];
                }
                header('Location: index.php');
            }
        }
    }
    ?>

</head>
<body>
<div class="log-w3">
    <div class="w3layouts-main">
        <h2>Sign In Now</h2>
        <form action="login.php" method="post">
            <input type="text" class="ggg" name="UserName" placeholder="User Name" required="">
            <input type="password" class="ggg" name="PassWord" placeholder="PASSWORD" required="">
            <span><input class="remember" type="checkbox" />Remember Me</span>
            <h6><a href="#">Forgot Password?</a></h6>
            <div class="clearfix"></div>
            <input type="submit" value="Sign In" name="login">
        </form>
        <p>Don't Have an Account ?<a href="registration.html">Create an account</a></p>
    </div>
</div>
<script src="../js/bootstrap.js"></script>
<script src="../js/jquery.dcjqaccordion.2.7.js"></script>
<script src="../js/scripts.js"></script>
<script src="../js/jquery.slimscroll.js"></script>
<script src="../js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="../js/jquery.scrollTo.js"></script>
</body>
</html>
