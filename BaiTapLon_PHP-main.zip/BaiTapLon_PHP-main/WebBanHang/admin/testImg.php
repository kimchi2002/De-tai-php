<?php
echo "<pre>";
print_r($_FILES['Logo']);
echo "</pre>";
?>