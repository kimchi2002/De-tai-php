<?php
    include 'header.php';
    include 'phanquyenNhanVien.php';
?>
<section id="main-content">
    <section class="wrapper">
<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            THÔNG TIN TÀI KHOẢN
        </div>

        <form action="" method="get">
            <table>
                <tr>
                    <td>
                        <input type="hidden" name = "option" value="Customer">
                        <input type="text" name="search">
                    </td>
                    <td>
                        &nbsp;&nbsp; <input type="submit" value="search">&nbsp;&nbsp;
                        <input type="button" value="All" onclick="window.location.href='../admin/updatetaiKhoan.php'">
                    </td>
                </tr>
            </table>
        </form>
        <br>

        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                <tr>


                    <th>Mã Tài Khoản</th>
                    <th>Tên Đăng Nhập</th>
<!--                    <th>Mật Khẩu</th>-->
                    <th>Tên Hiển Thị</th>
                    <th>Địa chỉ</th>
                    <th>Điện thoại</th>
                    <th>Email</th>
                    <th>Tình trạng</th>
                    <th>Tùy Chọn</th>

                </tr>
                </thead>
                <tbody>
                <?php
                include '../connect/conectdb.php';
                $result = mysqli_query($conn, 'select count(MaTaiKhoan) as total from taikhoan');
                $row = mysqli_fetch_assoc($result);
                $total_records = $row['total'];

                // BƯỚC 3: TÌM LIMIT VÀ CURRENT_PAGE
                $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
                $limit = 3;

                // BƯỚC 4: TÍNH TOÁN TOTAL_PAGE VÀ START
                // tổng số trang
                $total_page = ceil($total_records / $limit);

                // Giới hạn current_page trong khoảng 1 đến total_page
                if ($current_page > $total_page){
                    $current_page = $total_page;
                }
                else if ($current_page < 1){
                    $current_page = 1;
                }

                // Tìm Start
                $start = ($current_page - 1) * $limit;

                // BƯỚC 5: TRUY VẤN LẤY DANH SÁCH TIN TỨC
                // Có limit và start rồi thì truy vấn CSDL lấy danh sách tin tức
                if(ISSET($_GET['search'])&&!empty($_GET['search'])){
                    $key = addslashes($_GET['search']);
                //    //`MaLoaiTaiKhoan` = 1 and
                $result = mysqli_query($conn, "SELECT * FROM taikhoan where (`TenDangNhap` LIKE '%$key%' OR `MatKhau` LIKE '%$key%' OR `TenHienThi` LIKE '%$key%' OR `DiaChi` LIKE '%$key%' OR `DienThoai` LIKE '%$key%' OR `Email` LIKE '%$key%' OR `TinhTrang` LIKE '%$key%')");
                } else {
                //    $sql = "SELECT * FROM taikhoan  where (`TinhTrang` = 'hoạt động') and (LIMIT '$start_from', '$per_page_record')";

                $result = mysqli_query($conn, "SELECT * FROM taikhoan where  (`TinhTrang` = 'hoạt động') order by MaTaiKhoan LIMIT $start, $limit  ");}



                ?>

                <?php
                // PHẦN HIỂN THỊ TIN TỨC
                // BƯỚC 6: HIỂN THỊ DANH SÁCH TIN TỨC
                while ($row = mysqli_fetch_assoc($result)) {
                    // echo '<li>' . $row['MaTaiKhoan'] . '</li>';
                    echo '<tr>';
                    echo '<td>' . $row['MaTaiKhoan'] . '</td>';
                    echo '<td>' . $row['TenDangNhap'] . '</td>';
                    echo '<td>' . $row['TenHienThi'] . '</td>';
                    echo '<td>' . $row['DiaChi'] . '</td>';
                    echo '<td>' . $row['DienThoai'] . '</td>';
                    echo '<td>' . $row['Email'] . '</td>';
                    echo '<td>' . $row['TinhTrang'] . '</td>';
        //            echo '<td>'.
                        if($_SESSION['MaLoaiTaiKhoan'] == 1) {
                            echo '<td>' . '<a href="/BaiTapLon_PHP/WebBanHang/admin/Delete_Kh.php?MaTaiKhoan=' . $row['MaTaiKhoan'] . ' " onclick="return ConfirmDelete();" <button type="button">Delete</button> </a>' . '</td>';
                        }
//                        else{
//                            echo '<button type="button">Delete</button>';
//                        }
                        echo '</tr>';
                }
                ?>


                </tbody>
            </table>




        </div>

    </div>


    <nav style="text-align: center" aria-label="Page navigation example">
        <ul class="pagination">
            <li class="page-item">
                <?php echo '<a class="page-link" href="updatetaiKhoan.php?page='.($current_page-1).'" aria-label="Previous">Previous</a>' ?>
            </li>
            <?php
            for ($i = 1; $i <= $total_page; $i++){
                // Nếu là trang hiện tại thì hiển thị thẻ span
                // ngược lại hiển thị thẻ a
                if ($i == $current_page){
                    echo '<li class="page-item"><a class="page-link" href="updatetaiKhoan.php?page=">'.$i.'</a></li>';
                }
            }
            ?>
            <li class="page-item">
                <?php echo '<a class="page-link" href="updatetaiKhoan.php?page='.($current_page+1).'" aria-label="Next">Next</a>' ?>

            </li>
        </ul>
    </nav>
    <script>
        function ConfirmDelete()
        {
            var x = confirm("Do you really want to delete?");
            if (x==true) {
                alert("Xóa chứ!!");
            }else{
                alert("không Xóa!!");
            }
           // alert("này có muốn xóa thật không đấy!!!")
        }
    </script>
</div>
    </section>
</section>

