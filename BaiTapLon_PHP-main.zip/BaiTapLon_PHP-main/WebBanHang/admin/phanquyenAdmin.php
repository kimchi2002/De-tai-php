<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
<!--    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.0/dist/sweetalert2.min.css" type="text/css"/>-->
<!--    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.0/dist/sweetalert2.min.js"></script>-->
</head>
<body>
            <?php
            if (session_id() === '')
                session_start();

            if (empty($_SESSION['UserName']) && empty($_SESSION['Password']) && empty($_SESSION["TinhTrang"]) && empty($_SESSION["MaLoaiTaiKhoan"])) {
                header('Location: login.php');
            } else if (isset($_SESSION['UserName']) && isset($_SESSION['Password']) && isset($_SESSION["TinhTrang"]) && isset($_SESSION["MaLoaiTaiKhoan"]) ) {
                 $TinhTrang = $_SESSION['TinhTrang'];
                // $TenDangNhap = $_SESSION['UserName'];
                $MaLoaiTaiKhoan	= $_SESSION["MaLoaiTaiKhoan"];
                if ( $TinhTrang == "hoạt động" && ($MaLoaiTaiKhoan == 3  || $MaLoaiTaiKhoan == 2) ) {
                    // Nếu không phải nhân viên / admin thì xuất thông báo
//                    echo '<script>
//                           // document.querySelector().addEventListener("click",(event)=>{
//                                swal.fire({
//                                      icon: "error",
//                                      title: "Oops...",
//                                      text: "Something went wrong!",
//                                      footer: "<a href="index.php">Why do I have this issue?</a>"
//                                    })
//                          //  })
//                          </script>';
                    echo '<script>alert("b k phải là admin!!")</script>';
                    echo "<a href='index.php'> Click để về lại trang chủ</a>";
                    // echo $IdNhom . $TinhTrang;
                    // header('Location: login.php');
                    exit();
                   // require 'index.php';
                }
//                else if($MaLoaiTaiKhoan == '2'  || $MaLoaiTaiKhoan == '3'){
//                    echo '<script>alert("b k có quyền hạn!!")</script>';
//                    exit();
//                }

            }
          //  session_destroy();
            ?>
</body>
</html>



