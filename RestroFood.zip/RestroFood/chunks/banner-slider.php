<section class="fslider">
    <div class="slider">
        <ul class="slides">
            <li>
                <img src="images/banner3.jpg">
                <div class="caption center-align black-text">
                    <h3
                        style="font-size: 3rem !important; font-style: bold !important; font-family: 'Bree Serif', serif;">
                        RestroFood - The Quality Food!</h3>
                    <h5 class="light black-text text-lighten-3"><strong>We deliver Quality. Try us and then buy
                            us!</strong></h5>
                </div>
            </li>

            <li>
                <img src="images/banner4.jpg">
                <div class="caption center-align black-text">
                    <h3
                        style="font-size: 3rem !important; font-style: bold !important; font-family: 'Bree Serif', serif;">
                        Quality Food at Your Door!</h3>
                    <h5 class="light black-text text-lighten-3"><strong>We deliver Quality And We're doing this for
                            years!</strong></h5>
                </div>
            </li>
        </ul>

    </div>
</section>