<section class="fcards">
    <div class="row" style="padding-left: 50px; padding-right: 50px;">
        <div class="col s12 m12 l4" style="padding: 50px 5px;">
            <div class="card">
                <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="images/banner1.jpg">
                </div>
                <div class="card-content">
                    <span class="card-title activator grey-text text-darken-4">North Indian<i
                            class="material-icons right">more_vert</i></span>
                    <div class="card-content">
                        <p>Muốn thử loại món ăn trong danh mục này. Khám phá ngay!</p>
                    </div>
                </div>
                <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">North Indian<i
                            class="material-icons right">close</i></span>
                    <p>Ẩm thực Ấn Độ bao gồm nhiều loại ẩm thực vùng có nguồn gốc từ Ấn Độ. Với phạm vi của
                        đa dạng về loại đất, khí hậu và nghề nghiệp, những món ăn này khác nhau đáng kể từ mỗi
                        khác và sử dụng sôcôla, thảo mộc, rau và trái cây sẵn có tại địa phương. Các món ăn sau đó
                        phục vụ theo khẩu vị nhẹ, vừa hoặc nóng. Thực phẩm Ấn Độ cũng bị ảnh hưởng nặng nề
                        bởi các lựa chọn tôn giáo và văn hóa, như Ấn Độ giáo và các truyền thống.</p>
                </div>
            </div>
        </div>
        <div class="col s12 m12 l4" style="padding: 50px 5px;">
            <div class="card">
                <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="images/banner2.jpg">
                </div>
                <div class="card-content">
                    <span class="card-title activator grey-text text-darken-4">Chinese<i
                            class="material-icons right">more_vert</i></span>
                    <div class="card-content">
                        <p>Muốn thử loại món ăn trong danh mục này. Khám phá ngay!</p>
                    </div>
                </div>
                <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">Chinese<i
                            class="material-icons right">close</i></span>
                    <p>Ẩm thực Trung Quốc là một phần quan trọng của văn hóa Trung Quốc, bao gồm các món ăn có nguồn gốc
                        từ
                        các khu vực đa dạng của Trung Quốc.</p>
                </div>
            </div>
        </div>
        <div class="col s12 m12 l4" style="padding: 50px 5px;">
            <div class="card">
                <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="images/banner4.jpg">
                </div>
                <div class="card-content">
                    <span class="card-title activator grey-text text-darken-4">South Indian<i
                            class="material-icons right">more_vert</i></span>
                    <div class="card-content">
                        <p>Muốn thử loại món ăn trong danh mục này. Khám phá ngay!</p>
                    </div>
                </div>
                <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">Snacks<i
                            class="material-icons right">close</i></span>
                    <p>Ẩm thực Nam Ấn Độ bao gồm các món ăn của năm bang miền nam Ấn Độ Andhra Pradesh,
                        Karnataka, Kerala, Tamil Nadu và Telangana.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row center" style="margin-bottom: 50px;">
        <div class="col s12">
            <a href="food-categories.php" class="waves-effect waves-light btn"
                style="background: #ee6e73 !important;">Xem món ăn &raquo;</a>
        </div>
    </div>
</section>