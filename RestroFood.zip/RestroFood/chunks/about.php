<section class="fabout">
    <div class="section white center">
        <div class="row container">
            <h2 class="header">VỀ CHÚNG TÔI</h2>
            <p class="grey-text text-darken-3 lighten-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Laboriosam optio deserunt labore impedit maiores non consequuntur fugiat, nostrum animi dolor illum,
                distinctio veniam dicta, reiciendis voluptatum voluptas modi ad sequi assumenda! Eum beatae voluptatum
                quod labore voluptas quis sint dolorum, architecto autem at. Atque esse, adipisci similique consequuntur
                cupiditate unde recusandae consequatur accusantium culpa voluptate. Est, mollitia, debitis. Molestiae
                odio cupiditate odit, illo culpa mollitia sint possimus commodi nemo aperiam quia, harum nulla
                repellendus iusto. Eligendi nulla laudantium ratione deleniti nostrum. Commodi deleniti temporibus culpa
                consequatur perspiciatis quae quis, at non molestias dolores dolor quos, illum quidem nulla velit.
                Architecto, voluptate, id nobis, beatae quisquam omnis minima officia ab voluptas ipsa quia debitis,
                nemo error! Facilis, ullam. Laboriosam distinctio incidunt optio, impedit maiores eius asperiores amet
                totam facilis eaque in minus, repellat, architecto iure odio quod possimus. Quam, tempora hic. Ratione
                nihil eos tenetur vel veniam molestiae, enim maxime deserunt.</p>
            <a href="/RestroGirls/about-restro-girls.php" class="waves-effect waves-light btn"
                style="background: #ee6e73 !important;">Xem thêm &raquo;</a>
        </div>
</section>