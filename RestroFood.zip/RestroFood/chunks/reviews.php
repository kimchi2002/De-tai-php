<section class="freviews">

    <div class="section white center">
        <h3 class="header">Khách hàng của chúng tôi nói gì</h3>
        <div class="carousel myreviews" style="margin-bottom: 35px;">
            <a class="carousel-item" href="#one!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: #ee6e73 !important;">
                            <span class="white-text">"Thức ăn của nhà hàng này giống như thiên đường đối với tôi! nó như
                                vậy
                                ngon và ngon đến nỗi tôi không thể không đến đó vào mỗi cuối tuần!"<br>-<br>
                                <strong>Ramkesh Singh</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#two!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: #ee6e73 !important;">
                            <span class="white-text">"Thức ăn của nhà hàng này giống như thiên đường đối với tôi! nó như
                                vậy
                                ngon và ngon đến nỗi tôi không thể không đến đó vào mỗi cuối tuần!"<br>-<br>
                                <strong>Rohan
                                    Roy</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#three!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: #ee6e73 !important;">
                            <span class="white-text">"Thức ăn của nhà hàng này giống như thiên đường đối với tôi! nó như
                                vậy
                                ngon và ngon đến nỗi tôi không thể không đến đó vào mỗi cuối tuần!"<br>-<br>
                                <strong>Atul
                                    Chand</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#four!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: #ee6e73 !important;">
                            <span class="white-text">"Thức ăn của nhà hàng này giống như thiên đường đối với tôi! nó như
                                vậy
                                ngon và ngon đến nỗi tôi không thể không đến đó vào mỗi cuối tuần!"<br>-<br>
                                <strong>Farhan Ahmed</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#five!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: #ee6e73 !important;">
                            <span class="white-text">"Thức ăn của nhà hàng này giống như thiên đường đối với tôi! nó như
                                vậy
                                ngon và ngon đến nỗi tôi không thể không đến đó vào mỗi cuối tuần!"<br>-<br>
                                <strong>Riya
                                    Dutta</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#six!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: #ee6e73 !important;">
                            <span class="white-text">"Thức ăn của nhà hàng này giống như thiên đường đối với tôi! nó như
                                vậy
                                ngon và ngon đến nỗi tôi không thể không đến đó vào mỗi cuối tuần!"<br>-<br>
                                <strong>Jasmine Sinha</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
            <a class="carousel-item" href="#seven!">
                <div class="row">
                    <div class="col s12">
                        <div class="card-panel teal" style="background: #ee6e73 !important;">
                            <span class="white-text">"Thức ăn của nhà hàng này giống như thiên đường đối với tôi! nó như
                                vậy
                                ngon và ngon đến nỗi tôi không thể không đến đó vào mỗi cuối tuần!"<br>-<br>
                                <strong>Sangjukta Roy</strong>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
</section>