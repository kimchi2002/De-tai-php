<section class="fabout">
    <div class="section white center">
        <div class="row container">
            <h2 class="header">VỀ CHÚNG TÔI</h2>
            <p class="grey-text text-darken-3 lighten-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas
                illo maiores commodi quia rerum, recusandae corporis consectetur. Nisi tempore distinctio dolorem
                facere, neque eaque ea! At ratione autem nemo, veniam molestias, atque quod explicabo quo non vel
                consequuntur voluptate obcaecati placeat quasi molestiae eaque sunt commodi debitis ipsum, deleniti
                error. At natus itaque eaque nemo sed sapiente aperiam maiores cumque adipisci, incidunt similique ullam
                iusto magnam dolorum provident aut recusandae consectetur sint saepe doloremque accusamus repudiandae.
                Provident repellat ab quis numquam excepturi veritatis modi, quia esse reprehenderit dolore laborum
                aliquam, explicabo reiciendis dignissimos ratione atque quisquam ut accusantium, harum natus! Suscipit,
                soluta optio. Quod in quia voluptatem nostrum veniam recusandae fuga placeat doloremque, quibusdam,
                cumque esse ea totam ut temporibus sed voluptatum tenetur similique incidunt molestiae debitis id?
                Quaerat doloremque unde reprehenderit voluptates quod corporis debitis doloribus molestias dicta,
                voluptatum atque vero, enim rem libero aliquam facere quasi aut nobis voluptatem voluptas dolorum
                nesciunt vitae. Quia velit sed nisi perspiciatis corporis ut nesciunt neque sit tenetur suscipit
                laudantium, rerum, quam temporibus iste saepe. Recusandae aperiam, tenetur omnis corrupti, magni
                possimus eum placeat repellendus necessitatibus natus molestias ad harum quo hic dolor architecto
                voluptate eveniet quis! Corporis repellendus commodi omnis quaerat blanditiis quibusdam mollitia veniam
                repellat molestiae. Officiis quam officia odit, consequatur molestiae, reiciendis, quas optio
                laboriosam, magni incidunt voluptatem cumque consectetur nobis necessitatibus? Rerum blanditiis
                voluptate eveniet maiores atque suscipit, nostrum ea eaque, quod ducimus nulla consectetur autem, dolore
                doloremque! Dicta placeat magnam dolor vero rerum, tempore porro laborum quae fugiat, est ut tempora
                nisi fuga eos, ducimus nesciunt! Hic ad rerum quia alias, autem illum, ipsam, libero possimus voluptatem
                optio minima! Deserunt delectus, veniam impedit, ab et cumque quaerat rem laboriosam, in consectetur non
                ratione voluptatum eos hic sint minus eveniet vero explicabo. Reiciendis officia iure quidem alias et.
            </p>
        </div>
</section>