<section class="fnavbar">
    <div class="navbar-fixed">
        <nav>
            <div class="nav-wrapper">
                <a href="#" class="brand-logo">RestroFood</a>
                <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">Menu</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="/RestroGirls" class="hvr-grow">Trang chủ</a></li>
                    <li><a href="/RestroGirls/about-restro-girls.php" class="hvr-grow">Về chúng tôi</a></li>
                    <li><a href="food-categories.php" class="hvr-grow">Danh mục</a></li>
                    <li><a href="foods.php" class="hvr-grow">Món Ăn</a></li>
                    <li><a href="#" class="hvr-grow"
                            onclick="toggleModal('Liên hệ', 'YBạn có thể liên hệ trực tiếp với chúng tôi bằng cách gọi đến số này +81-225-314-3456. Kiểm tra phần Footer dưới cùng của trang web để biết thêm thông tin.');">Liên
                            hệ</a>
                    </li>

                    <?php

					if (isset($_SESSION['user'])) {
						echo '<li><a href="#" class="hvr-grow">Hi, ' . $_SESSION['user'] . '</a></li>
		        		<li><a href="logout.php" class="hvr-grow">Đăng xuất</a></li>';
					} else {
						echo '<li><a href="#" class="hvr-grow modal-trigger" data-target="modal1">Đăng nhập</a></li>
		        		<li><a href="#" class="hvr-grow modal-trigger" data-target="modal2">Đăng ký</a></li>';
					}

					?>

                </ul>
            </div>
        </nav>
    </div>

    <ul class="sidenav" id="mobile-demo">
        <li><a href="/RestroGirls">Trang chủ</a></li>
        <li><a href="/RestroGirls/about-restro-girls.php">v</a></li>
        <li><a href="food-categories.php">Danh mục</a></li>
        <li><a href="foods.php">Món Ăn</a></li>
        <li><a href="#"
                onclick="toggleModal('Liên hệ', 'YBạn có thể liên hệ trực tiếp với chúng tôi bằng cách gọi đến số này +81-225-314-3456. Kiểm tra phần Footer dưới cùng của trang web để biết thêm thông tin.');">Liên
                hệ</a>
        </li>

        <?php

		if (isset($_SESSION['user'])) {
			echo '<li><a href="#">Hi, ' . $_SESSION['user'] . '</a></li>
		        		<li><a href="logout.php">Logout</a></li>';
		} else {
			echo '<li><a href="#" class="modal-trigger" data-target="modal1">Đăng nhập</a></li>
		        		<li><a href="#" class="modal-trigger" data-target="modal2">Đăng ký</a></li>';
		}

		?>
    </ul>
</section>